#!/bin/sh
# javaw must be in the path, e.g c:\java\bin
java -jar lib/eSCAPe-1.0.0.jar &
